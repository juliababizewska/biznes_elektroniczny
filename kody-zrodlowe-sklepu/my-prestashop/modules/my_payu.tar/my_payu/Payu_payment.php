<?php

if (!defined('_PS_VERSION_')) {
    exit;
}

class Payu_payment extends PaymentModule
{
    public function __construct()
    {
        $this->name = 'Payu_payment';
        $this->tab = 'Gateway';
        $this->version = '1.0.0';
        $this->author = 'PayU-author';
        $this->ps_versions_compliancy = ['min' => '1.7.0.0', 'max' => _PS_VERSION_];
        $this->bootstrap = true;

        parent::__construct();

        $this->displayName = $this->l('My Custom Payment');
        $this->description = $this->l('Custom payment method for localhost.');

        $this->confirmUninstall = $this->l('Are you sure you want to uninstall?');
    }

    public function install()
    {
        if (!parent::install() || !$this->registerHook('paymentOptions')) {
            return false;
        }
        return true;
    }

    public function uninstall()
    {
        return parent::uninstall();
    }

    public function hookPaymentOptions($params)
    {
        $newOption = new PrestaShop\PrestaShop\Core\Payment\PaymentOption();
        $newOption->setCallToActionText($this->l('Pay with Custom Method'))
                  ->setAction($this->context->link->getModuleLink($this->name, 'validation', [], true))
                  ->setAdditionalInformation($this->l('You will confirm your order manually.'));

        return [$newOption];
    }

    public function postProcess()
    {
        $cart = $this->context->cart;
        if (!$this->active) {
            Tools::redirect('index.php?controller=order');
        }

        $orderTotal = $cart->getOrderTotal(true, Cart::BOTH);
        $this->validateOrder(
            $cart->id,
            Configuration::get('PS_OS_PAYMENT'),
            $orderTotal,
            $this->displayName
        );
        Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->id.'&id_order='.$this->currentOrder.'&key='.$cart->secure_key);
    }
}

?>