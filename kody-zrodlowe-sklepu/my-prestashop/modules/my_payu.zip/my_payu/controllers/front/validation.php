<?php

// class Payu_paymentValidationModuleFrontController extends ModuleFrontController
// {
//     public function postProcess()
//     {
//         $cart = $this->context->cart;
//         if (!$this->module->active) {
//             Tools::redirect('index.php?controller=order');
//         }

//         $orderTotal = $cart->getOrderTotal(true, Cart::BOTH);
//         $this->module->validateOrder(
//             $cart->id,
//             Configuration::get('PS_OS_PAYMENT'),
//             $orderTotal,
//             $this->module->displayName
//         );
//         Tools::redirect('index.php?controller=order-confirmation&id_cart='.$cart->id.'&id_module='.$this->module->id.'&id_order='.$this->module->currentOrder.'&key='.$cart->secure_key);
//     }
// }

?>